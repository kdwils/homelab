# homelab-chart

![Version: 0.2.0](https://img.shields.io/badge/Version-0.2.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.16.0](https://img.shields.io/badge/AppVersion-1.16.0-informational?style=flat-square)

Helm chart for generic kubernetes deployments

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| kdwils |  | <https://github.com/kdwils> |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| certificate.certificates | list | `[]` |  |
| certificate.create | bool | `false` |  |
| clusterissuer.clusterissuers | list | `[]` |  |
| clusterissuer.create | bool | `false` |  |
| configmap.configmaps | list | `[]` |  |
| configmap.create | bool | `false` |  |
| configmaps | list | `[]` |  |
| daemonset.affinity | object | `{}` |  |
| daemonset.args | list | `[]` |  |
| daemonset.command | list | `[]` |  |
| daemonset.containers | list | `[]` |  |
| daemonset.create | bool | `false` |  |
| daemonset.dnsPolicy | string | `""` |  |
| daemonset.env | object | `{}` |  |
| daemonset.envFrom | list | `[]` |  |
| daemonset.fullnameOverride | string | `""` |  |
| daemonset.hostIPC | bool | `false` |  |
| daemonset.hostNetwork | bool | `false` |  |
| daemonset.hostPID | bool | `false` |  |
| daemonset.image.pullPolicy | string | `"IfNotPresent"` |  |
| daemonset.image.repository | string | `""` |  |
| daemonset.image.tag | string | `""` |  |
| daemonset.nameOverride | string | `""` |  |
| daemonset.nodeSelector | object | `{}` |  |
| daemonset.podAnnotations | object | `{}` |  |
| daemonset.podLabels | object | `{}` |  |
| daemonset.podSecurityContext | object | `{}` |  |
| daemonset.securityContext | object | `{}` |  |
| daemonset.tolerations | list | `[]` |  |
| daemonset.volumeMounts | list | `[]` |  |
| daemonset.volumes | list | `[]` |  |
| deployment.affinity | object | `{}` |  |
| deployment.args | list | `[]` |  |
| deployment.command | list | `[]` |  |
| deployment.containers | list | `[]` |  |
| deployment.create | bool | `false` |  |
| deployment.deployStrategy | string | `"RollingUpdate"` |  |
| deployment.dnsPolicy | string | `""` |  |
| deployment.env | object | `{}` |  |
| deployment.envFrom | list | `[]` |  |
| deployment.fullnameOverride | string | `""` |  |
| deployment.hostIPC | bool | `false` |  |
| deployment.hostNetwork | bool | `false` |  |
| deployment.hostPID | bool | `false` |  |
| deployment.hostname | string | `""` |  |
| deployment.image.pullPolicy | string | `"IfNotPresent"` |  |
| deployment.image.repository | string | `""` |  |
| deployment.image.tag | string | `""` |  |
| deployment.imagePullSecrets | list | `[]` |  |
| deployment.nameOverride | string | `""` |  |
| deployment.nodeSelector | object | `{}` |  |
| deployment.podAnnotations | object | `{}` |  |
| deployment.podLabels | object | `{}` |  |
| deployment.podSecurityContext | object | `{}` |  |
| deployment.replicas | int | `1` |  |
| deployment.resources | object | `{}` |  |
| deployment.securityContext | object | `{}` |  |
| deployment.tolerations | list | `[]` |  |
| deployment.volumeMounts | list | `[]` |  |
| deployment.volumes | list | `[]` |  |
| extraContainers | list | `[]` |  |
| extraServices | list | `[]` |  |
| httproute.create | bool | `false` |  |
| httproute.hostnames | list | `[]` |  |
| httproute.parentRefs | list | `[]` |  |
| httproute.rules | list | `[]` |  |
| httproutes | list | `[]` |  |
| ingress.annotations | object | `{}` |  |
| ingress.className | string | `""` |  |
| ingress.create | bool | `false` |  |
| ingress.hosts[0].host | string | `"chart-example.local"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"ImplementationSpecific"` |  |
| ingress.tls | list | `[]` |  |
| initContainers | list | `[]` |  |
| postgres.clusters | list | `[]` |  |
| pvc.create | bool | `false` |  |
| pvc.pvcs | list | `[]` |  |
| rbac.create | bool | `false` |  |
| rbac.rules | list | `[]` |  |
| securityPolicies | list | `[]` |  |
| securityPolicy | object | `{}` |  |
| service.create | bool | `false` |  |
| service.loadBalancerClass | string | `""` |  |
| service.name | string | `""` |  |
| service.port | int | `0` |  |
| service.ports | list | `[]` |  |
| service.protocol | string | `"TCP"` |  |
| service.targetPort | int | `0` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.automount | bool | `false` |  |
| serviceAccount.create | bool | `false` |  |
| serviceAccount.name | string | `""` |  |
| serviceMonitor.annotations | object | `{}` |  |
| serviceMonitor.enabled | bool | `false` |  |
| serviceMonitor.endpoints | list | `[]` |  |
| serviceMonitor.labels | object | `{}` |  |
| serviceMonitor.namespace | string | `""` |  |
| serviceMonitor.release | string | `""` |  |
| tcproute.annotations | object | `{}` |  |
| tcproute.create | bool | `false` |  |
| tcproute.hostnames | list | `[]` |  |
| tcproute.parentRefs | list | `[]` |  |
| tcproute.rules | list | `[]` |  |
| tcproutes | list | `[]` |  |
| tlsroute.create | bool | `false` |  |
| tlsroute.hostnames | list | `[]` |  |
| tlsroute.parentRefs | list | `[]` |  |
| tlsroute.rules | list | `[]` |  |
| tlsroutes | list | `[]` |  |
| udproute.annotations | object | `{}` |  |
| udproute.create | bool | `false` |  |
| udproute.hostnames | list | `[]` |  |
| udproute.parentRefs | list | `[]` |  |
| udproute.rules | list | `[]` |  |
| udproutes | list | `[]` |  |
| verticalPodAutoscaler.enabled | bool | `false` |  |
| verticalPodAutoscaler.resourcePolicy | object | `{}` |  |
| verticalPodAutoscaler.targetRef.apiVersion | string | `"apps/v1"` |  |
| verticalPodAutoscaler.targetRef.kind | string | `"Deployment"` |  |
| verticalPodAutoscaler.targetRef.name | string | `""` |  |
| verticalPodAutoscaler.updatePolicy.updateMode | string | `"Initial"` |  |
| verticalPodAutoscalers | list | `[]` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
