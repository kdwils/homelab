package main

# validate serviceAccountName
deny[msg] {
  input.kind == "DaemonSet"
  endswith(input.metadata.name, "-speaker")
  serviceAccountName := input.spec.template.spec.serviceAccountName
  not serviceAccountName == "release-name-metallb-speaker"
  msg = sprintf("speaker serviceAccountName '%s' does not match expected value", [serviceAccountName])
}

# validate METALLB_ML_SECRET_KEY (memberlist)
deny[msg] {
	input.kind == "DaemonSet"
	endswith(input.metadata.name, "-speaker")
	not input.spec.template.spec.containers[0].env[5].name == "METALLB_ML_SECRET_KEY_PATH"
	msg = "speaker env does not contain METALLB_ML_SECRET_KEY_PATH at env[5]"
}

# validate node selector includes builtin when custom ones are provided
deny[msg] {
  input.kind == "DaemonSet"
  endswith(input.metadata.name, "-speaker")
  not input.spec.template.spec.nodeSelector["kubernetes.io/os"] == "linux"
  msg = "controller nodeSelector does not include '\"kubernetes.io/os\": linux'"
}

# validate tolerations include the builtins when custom ones are provided
deny[msg] {
  input.kind == "DaemonSet"
  endswith(input.metadata.name, "-speaker")
  not input.spec.template.spec.tolerations[0] == { "key": "node-role.kubernetes.io/master", "effect": "NoSchedule", "operator": "Exists" }
  msg = "controller tolerations does not include node-role.kubernetes.io/master:NoSchedule"
}
# validate exclude-L2 config is readable by a non-root speaker
deny[msg] {
  input.kind == "DaemonSet"
  endswith(input.metadata.name, "-speaker")
  volume := input.spec.template.spec.volumes[_]
  volume.name == "metallb-excludel2"
  not volume.configMap.defaultMode == 292
  msg = "speaker metallb-excludel2 ConfigMap defaultMode must be 292"
}
